const express = require('express');
const router = express.Router();
const Deposit = require('../models/Deposit');
const User = require('../models/User');
const { stkPush } = require('../config/mpesa');
const auth = require('../middleware/auth');

// initiate STK push
router.post('/initiate', auth, async (req, res) => {
  try {
    const { amount, phone } = req.body;
    if(!amount || !phone) return res.status(400).json({ error: 'Missing fields' });
    const deposit = await Deposit.create({ user: req.userId, amount, phone });
    const data = await stkPush({ amount, phone });
    deposit.mpesaCheckoutRequestId = data.CheckoutRequestID || data.checkoutRequestID || '';
    await deposit.save();
    res.json({ success: true, data });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

// simple webhook to update deposit status (you should verify callback contents)
router.post('/callback', async (req, res) => {
  console.log('callback body', req.body);
  // Implement parsing of callback and update Deposit accordingly
  res.json({ received: true });
});

module.exports = router;
