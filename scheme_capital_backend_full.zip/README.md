# Scheme Capital - Backend

## Quick start

1. Copy `.env.example` to `.env` and fill environment variables.
2. Install dependencies:
   ```
   npm install
   ```
3. Run in development:
   ```
   npm run dev
   ```
4. API endpoints:
   - POST /api/auth/register
   - POST /api/auth/login
   - POST /api/deposit/initiate (protected)
   - GET /api/user/me (protected)
