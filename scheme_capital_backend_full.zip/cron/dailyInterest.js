const cron = require('node-cron');
const User = require('../models/User');
const { computeDailyInterest } = require('../utils/interestCalculator');

module.exports.start = function() {
  // runs once per day at 00:05
  cron.schedule('5 0 * * *', async () => {
    console.log('Running daily interest job');
    try {
      const users = await User.find({});
      for(const u of users) {
        const interest = computeDailyInterest(u.balance);
        u.balance = u.balance + interest;
        await u.save();
      }
      console.log('Daily interest applied to users');
    } catch (err) {
      console.error('Interest job error', err);
    }
  });
};
