// daily interest calculator based on ANNUAL_RATE env variable
module.exports.computeDailyInterest = function(balance) {
  const annual = parseFloat(process.env.ANNUAL_RATE || '0.10');
  const dailyRate = annual / 365;
  return balance * dailyRate;
};
