const axios = require('axios');
const qs = require('qs');

async function getAccessToken() {
  const key = process.env.DARAJA_KEY;
  const secret = process.env.DARAJA_SECRET;
  const auth = Buffer.from(`${key}:${secret}`).toString('base64');
  const url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
  const resp = await axios.get(url, { headers: { Authorization: `Basic ${auth}` } });
  return resp.data.access_token;
}

async function stkPush({ amount, phone, accountRef='Scheme Capital', transactionDesc='Deposit to Scheme Capital' }) {
  const accessToken = await getAccessToken();
  const shortcode = process.env.DARAJA_SHORTCODE;
  const passkey = process.env.DARAJA_PASSKEY;
  const timestamp = new Date().toISOString().replace(/[^0-9]/g, '').slice(0,14);
  const password = Buffer.from(shortcode + passkey + timestamp).toString('base64');

  const body = {
    BusinessShortCode: shortcode,
    Password: password,
    Timestamp: timestamp,
    TransactionType: 'CustomerPayBillOnline',
    Amount: amount,
    PartyA: phone,
    PartyB: shortcode,
    PhoneNumber: phone,
    CallBackURL: process.env.MPESA_CALLBACK_URL,
    AccountReference: accountRef,
    TransactionDesc: transactionDesc
  };

  const resp = await axios.post('https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest', body, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  return resp.data;
}

module.exports = { getAccessToken, stkPush };
